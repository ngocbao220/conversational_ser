# IEMOCAP Context and Interaction Examples

These examples were mined from Session 5 predictions and transcripts. They are illustrative cases, not causal proof.

Prediction sources:
- Baseline: `results/main/wavlm/baseline/cross_session/run_20260630_091825/test_Ses05/predictions.csv`
- CDM: `results/main/wavlm/cdm/cross_session/run_20260630_092932/test_Ses05/predictions.csv`
- CDIM early-fusion residual-gate: `results/architecture_ablation/residual_gate/cross_session/run_20260702_115526/test_Ses05/predictions.csv`

## 1. Context Examples

### Example C1: Sadness is clear from the previous dialogue state

Target utterance: `Ses05F_impro02_F024`

Gold: `sad`

Without context, Baseline predicts `neutral` with confidence `0.31`.

With dialogue memory, CDM predicts `sad` with confidence `0.93`.

Local context:

| turn | speaker | gold | text |
|---|---|---|---|
| `Ses05F_impro02_M025` | M | sad | It's not fair. |
| `Ses05F_impro02_F023` | F | sad | I know. I know it's not fair. |
| `Ses05F_impro02_M026` | M | sad | Why has to be you? There's all those other people. Somebody else can go instead. It's not right. |
| `Ses05F_impro02_F024` | F | sad | Well, apparently nobody else can go. |

Interpretation: The target utterance is short and acoustically can sound flat/neutral. The preceding turns establish a sustained sad state, so CDM can recover the emotion from conversational context.

### Example C2: Happy/excited tone depends on the ongoing topic

Target utterance: `Ses05M_impro03_M026`

Gold: `happy`

Without context, Baseline predicts `angry` with confidence `0.36`.

With dialogue memory, CDM predicts `happy` with confidence `0.96`.

Local context:

| turn | speaker | gold | text |
|---|---|---|---|
| `Ses05M_impro03_M024` | M | happy | Of course. I told them right away. We called them all right them. |
| `Ses05M_impro03_F022` | F | happy | Are they so excited? |
| `Ses05M_impro03_M025` | M | happy | Oh, yeah. My mom's freaking out. Oh yeah, She's so happy. this is you know It's her dream come true. |
| `Ses05M_impro03_M026` | M | happy | She wants grandkids. So we'll be working on that right away. |

Interpretation: The utterance alone may not contain enough acoustic evidence for happy. The previous speaker state and topic trajectory make the happy label more plausible.

## 2. Interaction Behavior Examples

### Example I1: Overlap and interruption help distinguish neutral from angry

Target utterance: `Ses05F_impro04_M030`

Gold: `neutral`

Without interaction memory, CDM predicts `angry` with confidence `0.53`.

With CDIM, the early-fusion residual-gate model predicts `neutral` with confidence `0.77`.

Interaction features:

| feature | value |
|---|---:|
| duration | 1.920 |
| gap_prev | -0.930 |
| relative_gap | -0.487 |
| overlap_ratio | 0.484 |
| speaker_switch | true |
| is_interrupting_prev | true |
| speaker_overlap | 0.806 |

Local context:

| turn | speaker | gold | text |
|---|---|---|---|
| `Ses05F_impro04_F030` | F | ignore | Yeah, and I look nice and I'm you know-- |
| `Ses05F_impro04_M029` | M | neutral | Are you presenting- |
| `Ses05F_impro04_F031` | F | ignore | charismatic. |
| `Ses05F_impro04_M030` | M | neutral | putting your best foot forward? or you |

Interpretation: The turn is produced during overlapping speech and speaker switching. CDM alone overreads the tense context as angry, while CDIM can use the timing pattern to treat the utterance as a neutral continuation/repair in a fast exchange.

### Example I2: Strong interruption in an emotional dialogue

Target utterance: `Ses05F_impro06_M007`

Gold: `sad`

Without interaction memory, CDM predicts `neutral` with confidence `0.51`.

With CDIM, the early-fusion residual-gate model predicts `sad` with confidence `0.53`.

Interaction features:

| feature | value |
|---|---:|
| duration | 1.750 |
| gap_prev | -1.030 |
| relative_gap | -1.383 |
| overlap_ratio | 0.589 |
| speaker_switch | true |
| is_interrupting_prev | true |
| speaker_overlap | 0.143 |

Local context:

| turn | speaker | gold | text |
|---|---|---|---|
| `Ses05F_impro06_M005` | M | sad | Absolutely, absolutely. |
| `Ses05F_impro06_M006` | M | sad | It's the think |
| `Ses05F_impro06_F007` | F | sad | I just, I don't know. |
| `Ses05F_impro06_M007` | M | sad | There's no reason for it. |

Interpretation: The utterance is brief and overlaps with a preceding sad exchange. The timing behavior supports reading it as part of an emotionally loaded back-and-forth rather than an isolated neutral statement.

### Example I3: Fast speaker switching prevents happy-context bias

Target utterance: `Ses05M_impro03_F027`

Gold: `neutral`

Without interaction memory, CDM predicts `happy` with confidence `0.77`.

With CDIM, the early-fusion residual-gate model predicts `neutral` with confidence `0.51`.

Interaction features:

| feature | value |
|---|---:|
| duration | 3.730 |
| gap_prev | -2.090 |
| relative_gap | -0.931 |
| overlap_ratio | 0.560 |
| speaker_switch | true |
| is_interrupting_prev | true |
| speaker_overlap | 0.793 |

Local context:

| turn | speaker | gold | text |
|---|---|---|---|
| `Ses05M_impro03_M028` | M | happy | She wants like eight- She wants like eight kids and I'm like, no, no, no, no, no. |
| `Ses05M_impro03_F026` | F | neutral | Are you going to start right away? |
| `Ses05M_impro03_M029` | M | happy | Well, we're going to take a little bit of time, you know, we need to get acclimated... |
| `Ses05M_impro03_F027` | F | neutral | Yeah, have you ever like lived with someone else before? |

Interpretation: CDM follows the happy dialogue topic, but the target speaker's quick interleaving question functions as neutral turn management. Interaction timing helps reduce the context-induced happy bias.
